package br.edu.infnet.appvinho;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppvinhoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppvinhoApplication.class, args);
	}

}
