package br.edu.infnet.appvinho;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppvinhoApplicationTests {

	@Test
	void contextLoads() {
	}

}
